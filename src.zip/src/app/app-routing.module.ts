import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DestComponent } from './dest/dest.component';
import { DestMainComponent } from './dest-main/dest-main.component';
import { DestMahabaleshwarComponent } from './dest-mahabaleshwar/dest-mahabaleshwar.component';
import { DestLonavlaComponent } from './dest-lonavla/dest-lonavla.component';




const routes: Routes = [{path :'hill',
component : DestMainComponent},
{path :'khan',
component :DestComponent},
{path :'maha',
component : DestMahabaleshwarComponent},
{path :'lona',
component : DestLonavlaComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
