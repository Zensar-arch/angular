import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DestComponent } from './dest/dest.component';
import { DestMainComponent } from './dest-main/dest-main.component';
import { DestLonavlaComponent } from './dest-lonavla/dest-lonavla.component';
import { DestMahabaleshwarComponent } from './dest-mahabaleshwar/dest-mahabaleshwar.component';
import { DestMumbaiComponent } from './dest-mumbai/dest-mumbai.component';

@NgModule({
  declarations: [
    AppComponent,
    DestComponent,
    DestMainComponent,
    DestLonavlaComponent,
    DestMahabaleshwarComponent,
    DestMumbaiComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
