import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DestLonavlaComponent } from './dest-lonavla.component';

describe('DestLonavlaComponent', () => {
  let component: DestLonavlaComponent;
  let fixture: ComponentFixture<DestLonavlaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DestLonavlaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DestLonavlaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
