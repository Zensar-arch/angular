import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dest-lonavla',
  templateUrl: './dest-lonavla.component.html',
  styleUrls: ['./dest-lonavla.component.css']
})
export class DestLonavlaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
