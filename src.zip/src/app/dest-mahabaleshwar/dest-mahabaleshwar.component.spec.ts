import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DestMahabaleshwarComponent } from './dest-mahabaleshwar.component';

describe('DestMahabaleshwarComponent', () => {
  let component: DestMahabaleshwarComponent;
  let fixture: ComponentFixture<DestMahabaleshwarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DestMahabaleshwarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DestMahabaleshwarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
