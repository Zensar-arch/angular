import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dest-mahabaleshwar',
  templateUrl: './dest-mahabaleshwar.component.html',
  styleUrls: ['./dest-mahabaleshwar.component.css']
})
export class DestMahabaleshwarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
