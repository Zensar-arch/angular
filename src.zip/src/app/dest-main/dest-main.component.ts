import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dest-main',
  templateUrl: './dest-main.component.html',
  styleUrls: ['./dest-main.component.css']
})
export class DestMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
