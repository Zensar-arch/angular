import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DestMumbaiComponent } from './dest-mumbai.component';

describe('DestMumbaiComponent', () => {
  let component: DestMumbaiComponent;
  let fixture: ComponentFixture<DestMumbaiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DestMumbaiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DestMumbaiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
