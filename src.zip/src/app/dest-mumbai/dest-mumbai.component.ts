import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dest-mumbai',
  templateUrl: './dest-mumbai.component.html',
  styleUrls: ['./dest-mumbai.component.css']
})
export class DestMumbaiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
