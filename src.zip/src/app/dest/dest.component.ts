import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dest',
  templateUrl: './dest.component.html',
  styleUrls: ['./dest.component.css']
})
export class DestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
